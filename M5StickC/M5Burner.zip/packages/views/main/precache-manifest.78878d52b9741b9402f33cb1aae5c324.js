self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "b9cbbbada0340ddd51de34988d964840",
    "url": "./index.html"
  },
  {
    "revision": "20aef7e53423f4a3ec70",
    "url": "./static/css/main.946f84fb.chunk.css"
  },
  {
    "revision": "d54adaaf5b6e225adfbd",
    "url": "./static/js/2.e93faacf.chunk.js"
  },
  {
    "revision": "3453b8997016469371284a28c0e873e2",
    "url": "./static/js/2.e93faacf.chunk.js.LICENSE.txt"
  },
  {
    "revision": "20aef7e53423f4a3ec70",
    "url": "./static/js/main.ed632e02.chunk.js"
  },
  {
    "revision": "ace1bb7e844b6eeef1bf",
    "url": "./static/js/runtime-main.f4675d7a.js"
  }
]);